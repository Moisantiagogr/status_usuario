import { createContext } from "react";

// User signed - null
// user - dispatch
// Dispatch se refiere a que se hará un cambio
const AuthContext = createContext();

export default AuthContext;